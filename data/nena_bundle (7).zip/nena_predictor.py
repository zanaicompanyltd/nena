"""
nena_predictor.py — drop this file + nena_prototypes.pt + nena_vocabulary.json
into your backend and call predict_frame() or predict_video().

Requirements: pip install open-clip-torch opencv-python torch Pillow
"""
import json, torch, cv2, numpy as np
from PIL import Image
from pathlib import Path
import open_clip

# ── Load once at startup ──────────────────────────────────────
_MODEL, _PREPROCESS, _TOKENIZER, _PROTOTYPES, _VOCAB = None, None, None, None, None

def _load(artefact_dir="."):
    global _MODEL, _PREPROCESS, _TOKENIZER, _PROTOTYPES, _VOCAB
    if _MODEL is not None:
        return
    device = "cuda" if torch.cuda.is_available() else "cpu"
    _MODEL, _, _PREPROCESS = open_clip.create_model_and_transforms(
        "ViT-B-32", pretrained="laion2b_s34b_b79k"
    )
    _MODEL = _MODEL.to(device).eval()
    _TOKENIZER = open_clip.get_tokenizer("ViT-B-32")

    raw = torch.load(f"{artefact_dir}/nena_prototypes.pt", map_location=device)
    _PROTOTYPES = {k: v.to(device) for k, v in raw.items()}

    with open(f"{artefact_dir}/nena_vocabulary.json") as f:
        _VOCAB = {s["id"]: s for s in json.load(f)}

def _embed(frame_bgr, device):
    rgb  = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    t    = _PREPROCESS(Image.fromarray(rgb)).unsqueeze(0).to(device)
    with torch.no_grad():
        feat = _MODEL.encode_image(t)
        return feat / feat.norm(dim=-1, keepdim=True)

def predict_frame(frame_bgr, artefact_dir=".", threshold=0.28):
    """Single frame → sign prediction dict."""
    _load(artefact_dir)
    device = next(_MODEL.parameters()).device
    query  = _embed(frame_bgr, device)
    scores = {sid: (query @ p.T).item() for sid, p in _PROTOTYPES.items()}
    top3   = sorted(scores.items(), key=lambda x: -x[1])[:3]
    best_id, best_score = top3[0]
    if best_score < threshold:
        return {"sign_id": None, "swahili": None, "confidence": best_score, "top_3": []}
    result = lambda sid, sc: {"sign_id": sid, "swahili": _VOCAB[sid]["swahili"], "confidence": round(sc, 4)}
    return {**result(best_id, best_score), "top_3": [result(s, c) for s, c in top3]}

def predict_video(video_path, artefact_dir=".", threshold=0.28, n_frames=8):
    """Short video clip → sign prediction dict."""
    _load(artefact_dir)
    device = next(_MODEL.parameters()).device
    cap    = cv2.VideoCapture(video_path)
    total  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    idxs   = np.linspace(0, total-1, n_frames, dtype=int)
    frames = []
    for i in idxs:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(i))
        ret, f = cap.read()
        if ret: frames.append(f)
    cap.release()
    if not frames: return {"sign_id": None, "swahili": None, "confidence": 0.0, "top_3": []}
    feats  = [_embed(f, device) for f in frames]
    query  = torch.cat(feats, dim=0).mean(0, keepdim=True)
    query  = query / query.norm(dim=-1, keepdim=True)
    scores = {sid: (query @ p.T).item() for sid, p in _PROTOTYPES.items()}
    top3   = sorted(scores.items(), key=lambda x: -x[1])[:3]
    best_id, best_score = top3[0]
    if best_score < threshold:
        return {"sign_id": None, "swahili": None, "confidence": best_score, "top_3": []}
    result = lambda sid, sc: {"sign_id": sid, "swahili": _VOCAB[sid]["swahili"], "confidence": round(sc, 4)}
    return {**result(best_id, best_score), "top_3": [result(s, c) for s, c in top3]}
